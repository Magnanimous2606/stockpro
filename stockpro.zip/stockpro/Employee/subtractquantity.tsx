import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';

const SubtractQuantityScreen: React.FC = () => {
  const [siteName, setSiteName] = useState('');
  const [quantity, setQuantity] = useState('');

  const handleUseStock = () => {
    // Logic to subtract stock quantity
    console.log(`Site Name: ${siteName}, Quantity: ${quantity}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <FAIcon name="arrow-left" size={24} color="#333" style={styles.backIcon} />
        <Text style={styles.headerText}>Subtract Quantity</Text>
      </View>
      <View style={styles.imageContainer}>
        <Image source={require('../../images/bro.png')} style={styles.image} />
      </View>
      <TextInput
        style={styles.input}
        placeholder="Enter Site Name"
        value={siteName}
        onChangeText={setSiteName}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter Quantity"
        value={quantity}
        onChangeText={setQuantity}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.button} onPress={handleUseStock}>
        <Text style={styles.buttonText}>Use Stock</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backIcon: {
    marginRight: 10,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  input: {
    width: '100%',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  button: {
    padding: 15,
    backgroundColor: '#007bff',
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default SubtractQuantityScreen;

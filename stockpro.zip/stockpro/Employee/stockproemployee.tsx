import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../App'; // Adjust the path as necessary

type StockProEmployeeNavigationProp = StackNavigationProp<RootStackParamList, 'StockProEmployee'>;

const StockProEmployee: React.FC<{ navigation: StockProEmployeeNavigationProp }> = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>StockPro</Text>
      <Text style={styles.subtitle}>Welcome, Employee!</Text>
      <View style={styles.imageContainer}>
        <Image source={require('../../images/ami.png')} style={styles.image} />
      </View>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ScanItems')}>
        <FAIcon name="barcode" size={20} color="#000" style={styles.buttonIcon} />
        <Text style={styles.buttonText}>Scan Items</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('StockRequest')}>
        <FAIcon name="cart-plus" size={20} color="#000" style={styles.buttonIcon} />
        <Text style={styles.buttonText}>Stock Request</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SubtractQuantity')}>
        <FAIcon name="minus-circle" size={20} color="#000" style={styles.buttonIcon} />
        <Text style={styles.buttonText}>Subtract Quantity</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 20,
  },
  imageContainer: {
    marginBottom: 20,
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  button: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    width: '80%',
    justifyContent: 'center',
  },
  buttonIcon: {
    marginRight: 10,
  },
  buttonText: {
    fontSize: 16,
    color: '#000',
  },
});

export default StockProEmployee;

import React from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';

const StockRequestForm: React.FC = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <FAIcon name="arrow-left" size={24} color="#333" style={styles.backIcon} />
        <Text style={styles.headerText}>Stock Request</Text>
      </View>
      <View style={styles.imageContainer}>
        <Image source={require('../../images/bro.png')} style={styles.image} />
      </View>
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} placeholder="Enter Site Name" />
        <TextInput style={styles.input} placeholder="Enter Item Name" />
        <TextInput style={styles.input} placeholder="Enter Category" />
        <TextInput style={styles.input} placeholder="Enter Quantity" keyboardType="numeric" />
        <View style={styles.sizeContainer}>
          <TextInput style={styles.inputSize} placeholder="Enter Item Size" />
          <Text style={styles.sizeUnit}>ft</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Request Stock</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backIcon: {
    marginRight: 10,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  sizeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  inputSize: {
    flex: 1,
    padding: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  sizeUnit: {
    marginLeft: 10,
  },
  button: {
    padding: 15,
    backgroundColor: '#007bff',
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default StockRequestForm;
import React from 'react';
import { View, Text, TextInput, Button, StyleSheet, SafeAreaView, TouchableOpacity, Image, Platform } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../App'; // Adjust the path as necessary

type AddItemScreenNavigationProp = StackNavigationProp<RootStackParamList, 'AddItem'>;

const AddItemScreen: React.FC<{ navigation: AddItemScreenNavigationProp }> = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Add Item</Text>
      
      {/* Image View */}
      <View style={styles.splashContainer}>
        <Image source={require('../images/amico.png')} style={styles.image} />
      </View>
      
      {/* Input Fields View */}
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} placeholder="Item name" />
        <TextInput style={styles.input} placeholder="Category" />
        <TextInput style={styles.input} placeholder="Quantity" keyboardType="numeric" />
        <TouchableOpacity style={styles.addButton}>
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>

      {/* Navigation Bar */}
      <View style={styles.navBar}>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('StockPro')}>
          <FAIcon name="home" size={24} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Inventory')}>
          <FAIcon name="box-open" size={24} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('PendingRequests')}>
          <FAIcon name="clipboard-list" size={24} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('AddItem')}>
          <FAIcon name="plus" size={24} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Tools')}>
          <FAIcon name="cogs" size={24} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton} onPress={() => navigation.navigate('Wastage')}>
          <FAIcon name="trash-alt" size={24} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 20,
    textAlign: 'center',
  },
  splashContainer: {
    flex: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
    // resizeMode: 'contain',
  },
  inputContainer: {
    flex: 2,
    paddingHorizontal: 20,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
  },
  addButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#fff',
  },
  navButton: {
    alignItems: 'center',
  },
});

export default AddItemScreen;

import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Image } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../App'; // Adjust the path as necessary

type InventoryScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Inventory'>;

const InventoryScreen: React.FC<{ navigation: InventoryScreenNavigationProp }> = ({ navigation }) => {
  const [activeTab, setActiveTab] = useState<string>('stock');
  const items = [
    { id: 1001, name: 'Cement', stock: '20kg', category: 'Construction', image: require('../../images/cement.png') },
    { id: 1002, name: 'Red Paint', stock: '10 Liters', category: 'Paint & Coating', image: require('../../images/paint.png') },
    // Add more items here...
  ];

  const iconColor = (tab: string) => (tab === activeTab ? '#007BFF' : '#333');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Inventory</Text>
      <TextInput style={styles.searchBar} placeholder="Search items by name, quantity, cost" />
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        {items.map(item => (
          <View key={item.id} style={styles.inventoryItem}>
            {item.image && <Image source={item.image} style={styles.itemImage} />}
            <View style={styles.itemDetails}>
              <Text>#{item.id}</Text>
              <Text>Item Name: {item.name}</Text>
              <Text>In stock: {item.stock}</Text>
              <Text>Category: {item.category}</Text>
            </View>
            <View style={styles.itemActions}>
              <View style={styles.actionsRow}>
                <TouchableOpacity style={styles.actionButton}>
                  <FAIcon name="eye" size={20} color="#000" />
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <FAIcon name="edit" size={20} color="#000" />
                </TouchableOpacity>
              </View>
              <View style={styles.actionsRow}>
                <TouchableOpacity style={styles.actionButton}>
                  <FAIcon name="trash" size={20} color="#000" />
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <FAIcon name="barcode" size={20} color="#000" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
      <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('AddItem')}>
        <Text style={styles.addButtonText}>+ Add Item</Text>
      </TouchableOpacity>
      <View style={styles.navbar}>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'home' && styles.activeIcon]}
          onPress={() => navigation.navigate('StockPro')}>
          <FAIcon name="home" size={24} color={iconColor('home')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'requests' && styles.activeIcon]}
          onPress={() => navigation.navigate('PendingRequests')}>
          <FAIcon name="clipboard-list" size={24} color={iconColor('requests')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'stock' && styles.activeIcon]}
          onPress={() => navigation.navigate('Inventory')}>
          <FAIcon name="box-open" size={24} color={iconColor('stock')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'add' && styles.activeIcon]}
          onPress={() => navigation.navigate('AddItem')}>
          <FAIcon name="plus" size={24} color={iconColor('add')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'tools' && styles.activeIcon]}
          onPress={() => navigation.navigate('Tools')}>
          <FAIcon name="tools" size={24} color={iconColor('tools')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'wastage' && styles.activeIcon]}
          onPress={() => navigation.navigate('Wastage')}>
          <FAIcon name="trash-alt" size={24} color={iconColor('wastage')} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  searchBar: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 20,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 10,
  },
  inventoryItem: {
    flexDirection: 'row',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  itemImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  itemDetails: {
    flex: 1,
  },
  itemActions: {
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  actionButton: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    marginLeft: 5,
  },
  addButton: {
    padding: 10,
    backgroundColor: '#28A745',
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#fff',
    paddingVertical: 12,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    elevation: 8,
  },
  iconContainer: {
    padding: 8,
  },
  activeIcon: {
    backgroundColor: '#d9d9d9',
    borderRadius: 12,
  },
});

export default InventoryScreen;

import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Image, Alert, SafeAreaView } from 'react-native';
import FAIcon from 'react-native-vector-icons/FontAwesome5';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../App'; // Adjust the path as necessary

type AddItemScreenNavigationProp = StackNavigationProp<RootStackParamList, 'AddItem'>;

const AddItemScreen: React.FC<{ navigation: AddItemScreenNavigationProp }> = ({ navigation }) => {
  const [itemName, setItemName] = useState('');
  const [category, setCategory] = useState('');
  const [quantity, setQuantity] = useState('');
  const [activeTab, setActiveTab] = useState<string>('add'); // Add this line

  const handleAddItem = () => {
    if (!itemName || !category || !quantity) {
      Alert.alert('Error', 'All fields are required');
    } else {
      // Add the item logic here...
      Alert.alert('Success', 'Item added successfully');
      // Reset the form
      setItemName('');
      setCategory('');
      setQuantity('');
    }
  };

  const iconColor = (tab: string) => (tab === activeTab ? '#007BFF' : '#333');

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Add Item</Text>
      <View style={styles.splashContainer}>
        <Image source={require('../../images/amico.png')} style={styles.image} />
      </View>
      <View style={styles.inputContainer}>
        <TextInput 
          style={styles.input} 
          placeholder="Item name" 
          value={itemName} 
          onChangeText={setItemName} 
        />
        <TextInput 
          style={styles.input} 
          placeholder="Category" 
          value={category} 
          onChangeText={setCategory} 
        />
        <TextInput 
          style={styles.input} 
          placeholder="Quantity" 
          keyboardType="numeric" 
          value={quantity} 
          onChangeText={setQuantity} 
        />
        <TouchableOpacity style={styles.addButton} onPress={handleAddItem}>
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.navbar}>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'home' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('home');
            navigation.navigate('StockPro');
          }}>
          <FAIcon name="home" size={24} color={iconColor('home')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'requests' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('requests');
            navigation.navigate('PendingRequests');
          }}>
          <FAIcon name="clipboard-list" size={24} color={iconColor('requests')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'stock' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('stock');
            navigation.navigate('Inventory');
          }}>
          <FAIcon name="box-open" size={24} color={iconColor('stock')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'add' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('add');
            navigation.navigate('AddItem');
          }}>
          <FAIcon name="plus" size={24} color={iconColor('add')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'tools' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('tools');
            navigation.navigate('Tools');
          }}>
          <FAIcon name="tools" size={24} color={iconColor('tools')} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.iconContainer, activeTab === 'wastage' && styles.activeIcon]}
          onPress={() => {
            setActiveTab('wastage');
            navigation.navigate('Wastage');
          }}>
          <FAIcon name="trash-alt" size={24} color={iconColor('wastage')} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 20,
    textAlign: 'center',
  },
  splashContainer: {
    flex: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 200,
    height: 200,
  },
  inputContainer: {
    flex: 2,
    paddingHorizontal: 20,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  addButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#fff',
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    elevation: 8,
  },
  iconContainer: {
    padding: 8,
  },
  activeIcon: {
    backgroundColor: '#d9d9d9',
    borderRadius: 12,
  },
});

export default AddItemScreen;

import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image, Platform } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from './App'; // Adjust the path as necessary

type LoginScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;

const LoginScreen: React.FC<{ navigation: LoginScreenNavigationProp }> = ({ navigation }) => {
  const [userType, setUserType] = useState('');

  const handleLogin = () => {
    if (userType === 'admin') {
      navigation.navigate('StockPro');
    } else if (userType === 'employee') {
      navigation.navigate('StockProEmployee'); // Updated this line
    } else {
      alert('Please choose a user type');
    }
  };

  return (
    <View style={styles.loginContainer}>
      <Text style={styles.loginTitle}>Login</Text>
      <Image source={require('../images/illustration.png')} style={styles.illustration} />
      <Picker selectedValue={userType} onValueChange={(itemValue) => setUserType(itemValue)}
        style={styles.picker}
        itemStyle={{ height: Platform.OS === 'ios' ? 200 : undefined }}
        mode={Platform.OS === 'ios' ? 'dialog' : 'dropdown'}>
        <Picker.Item label="Choose user type" value="" />
        <Picker.Item label="Admin" value="admin" />
        <Picker.Item label="Employee" value="employee" />
      </Picker>
      <TextInput style={styles.input} placeholder="Enter your ID" />
      <TextInput style={styles.input} placeholder="Enter your Password" secureTextEntry />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

const styles = StyleSheet.create({
  loginContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  picker: {
    width: '100%',
  },
  loginTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  illustration: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
});

export default LoginScreen;
function alert(arg0: string) {
    throw new Error('Function not implemented.');
}

